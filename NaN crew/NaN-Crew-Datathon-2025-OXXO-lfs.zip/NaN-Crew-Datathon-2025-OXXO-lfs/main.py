def main():
    print("Hello from datathon2025-oxxo!")


if __name__ == "__main__":
    main()
