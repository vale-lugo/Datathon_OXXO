import pandas as pd
import folium
from folium.plugins import MarkerCluster, HeatMap, FeatureGroupSubGroup

# Leer los archivos CSV
dim_tienda = pd.read_csv('datos/DIM_TIENDA.csv')
meta_ventas = pd.read_csv('datos/META_venta.csv')
venta = pd.read_csv('datos/Venta.csv')

# Calcular promedio de ventas por tienda
promedio_ventas = venta.groupby("TIENDA_ID")["VENTA_TOTAL"].mean().reset_index()
promedio_ventas.rename(columns={"VENTA_TOTAL": "VENTA_PROMEDIO"}, inplace=True)

# Unir metas de ventas con el catálogo de tienda
dim_tienda = dim_tienda.merge(meta_ventas, on="ENTORNO_DES", how="left")

# Unir ventas promedio y calcular éxito
tiendas_con_ventas = dim_tienda.merge(promedio_ventas, on="TIENDA_ID", how="left")
tiendas_con_ventas["EXITO"] = (tiendas_con_ventas["VENTA_PROMEDIO"] >= tiendas_con_ventas["Meta_venta"]).astype(int)

# Calcular índice de rendimiento (venta real / meta)
tiendas_con_ventas["INDICE_RENDIMIENTO"] = tiendas_con_ventas["VENTA_PROMEDIO"] / tiendas_con_ventas["Meta_venta"]

# Filtrar datos válidos para el análisis
tiendas_validas = tiendas_con_ventas.dropna(subset=['LATITUD_NUM', 'LONGITUD_NUM', 'INDICE_RENDIMIENTO'])

# Top 100 mejores y peores tiendas por índice de rendimiento
top_100 = tiendas_validas.nlargest(100, 'INDICE_RENDIMIENTO')
bottom_100 = tiendas_validas.nsmallest(100, 'INDICE_RENDIMIENTO')

# Análisis estadístico por tipo de tienda
estadisticas_por_tipo = tiendas_validas.groupby('ENTORNO_DES').agg({
    'TIENDA_ID': 'count',
    'VENTA_PROMEDIO': ['mean', 'std', 'min', 'max'],
    'Meta_venta': 'mean',
    'EXITO': ['mean', 'sum'],
    'MTS2VENTAS_NUM': ['mean', 'std'],
    'INDICE_RENDIMIENTO': ['mean', 'std', 'min', 'max']
}).round(2)

# Renombrar las columnas para mejor legibilidad
estadisticas_por_tipo.columns = [
    'Número de Tiendas',
    'Venta Promedio Media',
    'Desviación Estándar Ventas',
    'Venta Mínima',
    'Venta Máxima',
    'Meta de Venta Media',
    'Tasa de Éxito',
    'Número de Tiendas Exitosas',
    'Área de Venta Media (m²)',
    'Desviación Estándar Área',
    'Índice de Rendimiento Medio',
    'Desviación Estándar Índice',
    'Índice Mínimo',
    'Índice Máximo'
]

# Guardar estadísticas en CSV
estadisticas_por_tipo.to_csv('estadisticas_tiendas.csv')

# Crear un mapa centrado en México
mexico_center = [23.6345, -102.5528]
m = folium.Map(location=mexico_center, zoom_start=5)

# Clusters generales
cluster_exitosas = MarkerCluster(name='Tiendas Exitosas').add_to(m)
cluster_no_exitosas = MarkerCluster(name='Tiendas No Exitosas').add_to(m)

# Grupos para top y bottom 100
top_100_group = folium.FeatureGroup(name='Top 100 Tiendas Más Exitosas', show=False)
bottom_100_group = folium.FeatureGroup(name='Top 100 Tiendas Menos Exitosas', show=False)
m.add_child(top_100_group)
m.add_child(bottom_100_group)

# Marcadores generales
for idx, row in tiendas_validas.iterrows():
    # Crear el popup con información de la tienda
    popup_text = f"""
    <b>Tienda ID:</b> {row['TIENDA_ID']}<br>
    <b>Plaza:</b> {row['PLAZA_CVE']}<br>
    <b>Nivel Socioeconómico:</b> {row['NIVELSOCIOECONOMICO_DES']}<br>
    <b>Entorno:</b> {row['ENTORNO_DES']}<br>
    <b>Segmento:</b> {row['SEGMENTO_MAESTRO_DESC']}<br>
    <b>Venta Promedio:</b> ${row['VENTA_PROMEDIO']:,.2f}<br>
    <b>Meta de Venta:</b> ${row['Meta_venta']:,.2f}<br>
    <b>Índice de Rendimiento:</b> {row['INDICE_RENDIMIENTO']:.2f}<br>
    <b>Estado:</b> {'Exitoso' if row['EXITO'] == 1 else 'No Exitoso'}
    """
    
    # Definir el color del marcador según el éxito
    color = 'green' if row['EXITO'] == 1 else 'red'
    
    # Agregar el marcador al cluster correspondiente
    folium.Marker(
        location=[row['LATITUD_NUM'], row['LONGITUD_NUM']],
        popup=folium.Popup(popup_text, max_width=300),
        tooltip=f"Tienda {row['TIENDA_ID']} - Índice: {row['INDICE_RENDIMIENTO']:.2f}",
        icon=folium.Icon(color=color, icon='info-sign')
    ).add_to(cluster_exitosas if row['EXITO'] == 1 else cluster_no_exitosas)

# Marcadores para top 100
for idx, row in top_100.iterrows():
    popup_text = f"""
    <b>Tienda ID:</b> {row['TIENDA_ID']}<br>
    <b>Índice de Rendimiento:</b> {row['INDICE_RENDIMIENTO']:.2f}<br>
    <b>Venta Promedio:</b> ${row['VENTA_PROMEDIO']:,.2f}<br>
    <b>Meta de Venta:</b> ${row['Meta_venta']:,.2f}<br>
    """
    folium.CircleMarker(
        location=[row['LATITUD_NUM'], row['LONGITUD_NUM']],
        radius=8,
        color='blue',
        fill=True,
        fill_color='blue',
        fill_opacity=0.7,
        popup=folium.Popup(popup_text, max_width=250),
        tooltip=f"TOP: Tienda {row['TIENDA_ID']} - Índice: {row['INDICE_RENDIMIENTO']:.2f}"
    ).add_to(top_100_group)

# Marcadores para bottom 100
for idx, row in bottom_100.iterrows():
    popup_text = f"""
    <b>Tienda ID:</b> {row['TIENDA_ID']}<br>
    <b>Índice de Rendimiento:</b> {row['INDICE_RENDIMIENTO']:.2f}<br>
    <b>Venta Promedio:</b> ${row['VENTA_PROMEDIO']:,.2f}<br>
    <b>Meta de Venta:</b> ${row['Meta_venta']:,.2f}<br>
    """
    folium.CircleMarker(
        location=[row['LATITUD_NUM'], row['LONGITUD_NUM']],
        radius=8,
        color='orange',
        fill=True,
        fill_color='orange',
        fill_opacity=0.7,
        popup=folium.Popup(popup_text, max_width=250),
        tooltip=f"BOTTOM: Tienda {row['TIENDA_ID']} - Índice: {row['INDICE_RENDIMIENTO']:.2f}"
    ).add_to(bottom_100_group)

# Preparar los datos para el heatmap usando el índice de rendimiento como peso
heat_data = [[row['LATITUD_NUM'], row['LONGITUD_NUM'], row['INDICE_RENDIMIENTO']] 
             for _, row in tiendas_validas.iterrows()]

# Agregar la capa de heatmap con el índice de rendimiento
HeatMap(heat_data, radius=15, blur=20, max_zoom=1, name='Mapa de Calor (Índice de Rendimiento)').add_to(m)

# Agregar control de capas
folium.LayerControl().add_to(m)

# Guardar el mapa
m.save('mapa_tiendas.html')
